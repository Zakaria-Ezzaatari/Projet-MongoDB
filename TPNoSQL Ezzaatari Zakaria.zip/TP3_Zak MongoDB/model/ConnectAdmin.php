<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectAdmin extends Connect
    {
        public function addUser($login,$password,$role)
        {
            

            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $ins= $util->insertOne(
                ['login_user' => $login, 'login_password' => $password, 'login_role' => $role]
            );
        }

        function removeUser($user)
        {
           
            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $result= $util->deleteOne(
                ['login_user' => $user]
            );
            
        }

        function getUsers()
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM utilisateurs");
            $stmt->execute();
            $result=$stmt->fetchAll();
            return $result;*/

            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $result= $util->find(
            );
            return $result;
        }
    }