<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectEnseignant extends Connect
    {
        public function addSubject($cours,$description,$user)
        {
            $conn=$this->Connection();
            /*$stmt = $conn->prepare("INSERT INTO cours (nom_cours,description_cours,createur_cours) VALUES (?,?,?) ");
            $stmt->execute(array($cours,$description,$user));*/

            $util=$conn->cours;
                    
            $util->insertOne(
            ['nom_cours' => $cours, 'description_cours' => $description, 'createur_cours' => $user]
            );
        }

        public function updateSubjects($cours,$description,$check,$user)
        {
            $conn=$this->Connection();
            $util=$conn->cours;
            $table=$this->getSubjects($user);
            $table=iterator_to_array($table);
            foreach($check as $index)
            {
                $element=$table[$index]['nom_cours'];

                $ins= $util->updateOne(
                    ['nom_cours' => $element],
                    ['$set' => ["nom_cours" => $cours[$index],"description_cours" => $description[$index]]]
                );
            
                /*$stmt = $conn->prepare("UPDATE cours SET nom_cours=?,description_cours=? WHERE nom_cours=?");
                $stmt->execute(array($cours[$index],$description[$index],$element));*/
            }
            
            
            
        }


        public function removeSubjects($subject,$user)
        {
            $conn=$this->Connection();
            $util=$conn->cours;
            $table=$this->getSubjects($user);
            $table=iterator_to_array($table);
            foreach($subject as $index)
            {
            $element=$table[$index]['nom_cours'];
            
            $result= $util->deleteOne(
                ['nom_cours' => $element]
            );

            /*$stmt = $conn->prepare("DELETE FROM cours WHERE nom_cours= ?");
            $stmt->execute(array($element));*/
            }
        }

        public function getSubjects($user)
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM cours WHERE createur_cours=?");
            $stmt->execute(array($user));
            $result=$stmt->fetchAll();
            return $result;*/

            $conn=$this->Connection();
            $util=$conn->cours;
            $result= $util->find(
                ["createur_cours" => $user]
            );
            return $result;
        }
    }