<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectEleve extends Connect
    {
        public function getSubjects($user)
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM subscriptions WHERE eleve_sub=?");
            $stmt->execute(array($user));
            $result=$stmt->fetchAll();
            return $result;*/

            $conn=$this->Connection();
            $util=$conn->subscriptions;
            $result= $util->find(
                ['eleve_sub' => $user],
            );
            return $result;
        }
    
        public function allSubjects()
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM cours");
            $stmt->execute(array());
            $result=$stmt->fetchAll();
            return $result;*/

            $conn=$this->Connection();
            $util=$conn->cours;
            $result= $util->find(
            );
            return $result;

        }
    
        public function checkSubject($nom,$user)
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM subscriptions WHERE nom_sub=? AND eleve_sub=?");
            $stmt->execute(array($nom,$user));
            $result=$stmt->fetchAll();
            if($stmt->rowCount() == 0) 
            {
                return true;
            }
            else
            {
                return false;
            }*/

            $conn=$this->Connection();
            $util=$conn->subscriptions;
            $result= $util->findOne(
                ['nom_sub' => $nom, 'eleve_sub' => $user],
               
            );
            if(empty($result)) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public function subscribeSubjects($check,$user)
        {
            $conn=$this->Connection();
            $table=$this->allSubjects();
            $table=iterator_to_array($table);
            foreach($check as $index)
            {
                $nom=$table[$index]['nom_cours'];
                $description=$table[$index]['description_cours'];
                $enseignant=$table[$index]['createur_cours'];
                $check=$this->checkSubject($nom,$user);
                if($check==true)
                {
                    $util=$conn->subscription;
                    
                    $util->insertOne(
                    ['nom_sub' => $nom, 'description_sub' => $description, 'enseignant_sub' => $enseignant, 'eleve_sub' => $user]
                    );
                    
                    /*$stmt = $conn->prepare("INSERT INTO subscriptions (nom_sub,description_sub,enseignant_sub,eleve_sub) VALUES (?,?,?,?) ");
                    $stmt->execute(array($nom,$description,$enseignant,$user));
                    $util=$conn->utilisateurs;
                    $ins= $util->updateOne(
                        ['login_user' => $user],
                        ['$push' => 'sub':['sub.nom_sub' => $nom, 'sub.description_sub' => $description, 'sub.enseignant_sub' => $enseignant]]
            );*/
                }
            }
        }
    

    }