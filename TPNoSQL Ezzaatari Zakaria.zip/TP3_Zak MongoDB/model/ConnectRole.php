<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectRole extends Connect
    {
       
        function getRole($user)
        {
            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $result=$util->findOne(
                ['login_user' => $user],
                ['projection' => ['_id' =>0, 'login_role'=>1]]
            );
            if ($result->rowCount() !== 0)
            {
                return $result['login_role'];
            }
            else
            {
                return false;
            }
        }

    }