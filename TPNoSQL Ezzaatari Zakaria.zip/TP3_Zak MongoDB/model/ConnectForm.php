<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectForm extends Connect
    {        
        function verifyLogin($user,$password)
        {
            /*$conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE login_user = ? AND login_password= ?");
            $stmt->execute(array($user,$password));
            $result=$stmt->fetch();
            if($stmt->rowCount() !== 0) 
            {
               return true;
            }
            return false;*/
            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $result=$util->findOne(
                ['login_user' => $user, 'login_password' => $password]
                
            );
            if(!empty($result)) 
            {
               return true;
            }
            return false;


        }

        

        function getRole($user)
        {
            /*$conn=$this->Connection();
            $stmt = $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE login_user = ?");
            $stmt->execute(array($user));
            $result=$stmt->fetch();
            return $result;*/
            $conn=$this->Connection();
            $util=$conn->utilisateurs;
            $result=$util->findOne(
                ['login_user' => $user],
                ['projection' => ['_id' =>0, 'login_role'=>1]]
            );
            return $result['login_role'];
        }

        function addMessage($message,$user)
        {
            $conn=$this->Connection();
            $mess=$conn->messages;
            $ins= $mess->insertOne(
                ['post_message' => $message, 'user_message' => $user]
            );
        }

        function getMessages()
        {
            $conn=$this->Connection();
            $mess=$conn->messages;
            $result= $mess->find(
            );
            return $result;
        }

    }


?>