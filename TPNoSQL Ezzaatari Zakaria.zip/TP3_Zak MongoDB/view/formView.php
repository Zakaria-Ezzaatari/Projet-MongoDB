  

    <?php 
    include  __DIR__. "/../core/header.php";
    $_SESSION['user']=$data["user"];?>
    <h1>Hello <?php echo $_SESSION['user']?></h1>
    <h2>Post</h2>
    <form action="index.php?controller=login&action=message" method="post">
    <div class="mb-3">
        <label for="message" class="form-label">New message:</label>
        <textarea class="form-control" name="message" id="message" rows="3"></textarea>
    </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th scope="col">User</th>
                <th scope="col">Message</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            foreach(($data["messages"]) as $messages)
            {
                echo "<tr>";
                echo "<td>".$messages['user_message']."</td>";
                echo "<td>".$messages['post_message']."</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>