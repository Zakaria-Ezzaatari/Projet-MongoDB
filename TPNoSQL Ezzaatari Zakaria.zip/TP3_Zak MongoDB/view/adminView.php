<?php include  __DIR__. "/../core/header.php";?>

<h2>Add User</h2>

<form action="index.php?controller=admin&action=add" method="post">
<div class="mb-3">
  <label for="login" class="form-label">Votre Login</label>
  <input type="text" class="form-control form-control-sm" id="login" name="login">
  <label for="pass" class="form-label">Mot de passe</label>
  <input type="text" class="form-control form-control-sm" id="pass" name="pass">
  <label for="login" class="form-label">Rôle</label>
  <select class="form-select form-select-lg mb-3" name="role">
  <option value="eleve" selected>eleve</option>
  <option value="enseignant">enseignant</option>
  <option value="admin">admin</option>
</select>
</div>
<button type="submit" class="btn btn-primary">Submit</button>
</form>

<form action="index.php?controller=admin&action=remove" method="post">
  <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Login</th>
      <th scope="col">Rôle</th>
      <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
      <?php 
      
      foreach($data as $users)
      {
      echo "<tr>";

      echo "<td>".$users['login_user']."</td>";
      echo "<td>".$users['login_role']."</td>";
      echo "<td> <button name='remove' value='" . $users['login_user'] . "' type='submit' class='btn btn-danger'>Supprimer</button>";
      echo "</tr>";
      }
      ?>
    </tbody>
  </table>
</form>

</body>
</html>