<?php
    require ('vendor/autoload.php');
    class Connect
    {
        private $client;
        

        public function __construct()
        {
            //$db_cfg= require_once '../config/database.php';
            $this->client= new MongoDB\Client();
            
        }

        public function Connection()
        {
            $connection= $this->client->TP_NOSQL;
            return $connection;
        }
    }
    
?>