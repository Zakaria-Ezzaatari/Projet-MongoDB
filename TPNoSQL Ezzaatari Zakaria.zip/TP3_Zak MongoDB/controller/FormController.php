<?php


class FormController
{
    private $connect;
    private $Connection;

    public function __construct()
    {
        require_once __DIR__. "/../model/ConnectForm.php";
        require_once __DIR__ . "/../model/Login.php";

        $this->connect=new ConnectForm();
        $this->Connection=$this->connect->Connection();

    }

    public function run($action)
    {
        switch($action)
        {
            case "index" :
                $this->index();
                break;
            case "login" :
                $this->login();
                break;
            case "form" :
                $this->form();
                break;
            case "message" :
                $this->message();
                break;
            default:
                $this->index();
                break;
        }
    }

    public function index()
    {
        $this->view("index",array());
    }

    public function login()
    {
        if((isset($_POST["user"]))&&(isset($_POST["password"])))
        {
            $login=new Login($this->connect);
            $verify=$login->verify($_POST["user"],$_POST["password"]);
            if($verify==true)
            {
                $role=$login->getRole($_POST["user"]);
                $_SESSION['role']=$role;
                $_SESSION['user']=$_POST['user'];
                $this->run("form",array("user"=>$_POST["user"]));
            }
            else
            {
                $this->run("index");
            }        
        }
        else
        {
            $this->run("index");
        }
    }

    public function form()
    {
        if(isset($_SESSION["user"]))
        {
            $login=new Login($this->connect);
            $messages=$login->getMessages();
            $this->view("form",array(
                "user"=>$_SESSION["user"],
                "messages"=>$messages));
        }
        else
        {
            $this->run("index");
        }
    }

    public function message()
    {
        if((isset($_POST['message']))&&(isset($_SESSION['user'])))
        {
            $login=new Login($this->connect);
            $login->message($_POST['message'],$_SESSION['user']);
        }
        $this->run("form");
    }

    public function view($view,$array)
    {
        $data=$array;
        require_once __DIR__ . "/../view/" . $view . "View.php";
    }
}