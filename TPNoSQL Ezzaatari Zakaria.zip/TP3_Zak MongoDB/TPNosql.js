db=connect("TP_NOSQL");

db.utilisateurs.drop();
db.messages.drop();
db.subscriptions.drop();
db.cours.drop();

var ut1={
    login_user:"admin",
    login_password:"admin",
    login_role:"admin"
};

var ut2={
    login_user:"Eric Dupont",
    login_password:"Eric",
    login_role:"enseignant",
    
};

var co1={
    nom_cours:'RPG en PHP',
    description_cours:"Pretty good,huh?",
    createur_cours:"Eric Dupont"
}

var ut3={
    login_user:"Agent 47",
    login_password:"hm",
    login_role:"eleve",
    
};

var su1={
    nom_sub:"RPG en PHP",
    description_cours:"Pretty good,huh?",
    enseignant_sub: "Eric Dupont",
    eleve_sub: "Agent 47"
}

var ms1={
    post_message:"PLEASE",
    user_message:"admin"
}

db.utilisateurs.insert(ut1);
db.utilisateurs.insert(ut2);
db.utilisateurs.insert(ut3);
db.messages.insert(ms1);
db.cours.insert(co1);
db.subscriptions.insert(su1);