<?php

require_once 'config/global.php';

session_start();

if(isset($_GET["controller"]))
{
    $controllerObj=loadController($_GET["controller"]);
    launchAction($controllerObj);
}
else
{
    $controllerObj=loadController(CONTROLLER_DEFAULT);
    launchAction($controllerObj);
}

function loadController($controller)
{
    switch($controller)
    {
        case 'login':
            $strFileController='controller/FormController.php';
            require_once $strFileController;
            $controllerObj=new FormController();
            break;
        /*case 'role':
            $strFileController='controller/RoleController.php';
            require_once $strFileController;
            $controllerObj=new RoleController();
            break;*/
        case 'admin' :
            $strFileController='controller/AdminController.php';
            require_once $strFileController;
            $controllerObj=new AdminController();
            break;
        case 'enseignant' :
            $strFileController='controller/EnseignantController.php';
            require_once $strFileController;
            $controllerObj=new EnseignantController();
            break;
        case 'eleve' :
            $strFileController='controller/EleveController.php';
            require_once $strFileController;
            $controllerObj=new EleveController();
            break;
        default:
            $strFileController='controller/FormController.php';
            require_once $strFileController;
            $controllerObj=new FormController();
            break;
    }
    return $controllerObj;
}

function launchAction($controllerObj)
{
    if(isset($_GET["action"]))
    {
        $controllerObj->run($_GET["action"]);
    }
    else
    {
        $controllerObj->run(DEFAULT_ACTION);
    }
}
