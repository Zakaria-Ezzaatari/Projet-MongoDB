<?php
    class Connect
    {
        private $driver;
        private $host,$user,$pass,$database;

        public function __construct()
        {
            //$db_cfg= require_once '../config/database.php';
            $this->driver="mysql";
            $this->host="localhost";
            $this->user="root";
            $this->pass="";
            $this->database="tp3";
        }

        public function Connection()
        {
            $bdd= $this->driver . ':host=' . $this->host . ';dbname=' . $this->database . '';
            //$bdd=' mysql:host=localhost;dbname=TP3 ';
            
            try
            {
                $connection= new PDO($bdd,$this->user,$this->pass);
                $connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
                return $connection;
            }
            catch(PDOException $e)
            {
                throw new Exception("Error enstablishing the connection.");
                
            }
        }
    }
    
?>