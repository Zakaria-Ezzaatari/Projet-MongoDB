<?php include  __DIR__. "/../core/header.php";?>

<h1>Mes Cours</h1>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Description</th>
      <th scope="col">Ensegnant</th>
    </tr>
    </thead>
    <tbody>
    <?php 
        $count=0;
        foreach($data['subs'] as $subs)
        {
            echo "<tr>\n";
            echo "<td>\n";
            echo "" . $subs['nom_sub'] . "\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "" . $subs['description_sub'] . "\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "" . $subs['enseignant_sub'] . "\n";
            echo "</td>\n";
            echo "</tr>\n";
            $count++;
    }
    ?>
    </tbody>
  </table>

<h1>S'inscrire: </h1>
<form action="index.php?controller=eleve&action=subscribe" method="post">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th scope="col">Nom</th>
                <th scope="col">Description</th>
                <th scope="col">Enseignant</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $count=0;
                foreach($data['cours'] as $cours)
                {
                    echo "<tr>\n";
                    echo "<td>\n";
                    echo"" . $cours['nom_cours'] ."\n";
                    echo "</td>\n";
                    echo "<td>\n";
                    echo "" . $cours['description_cours'] . "\n";
                    echo "</td>\n";
                    echo "<td>\n";
                    echo "" . $cours['createur_cours'] . "\n";
                    echo "</td>\n";
                    echo "<td>\n";
                    echo "<div class='form-check'>\n";
                    echo "<input class='form-check-input' type='checkbox' value='" . $count . "' name='checkbox[]' id='flexCheckDefault'>\n";
                    echo "</div>\n";
                    echo "</td>\n";
                    echo "</tr>\n";
                    $count++;
            }
            ?>
        </tbody>
    </table>
<button type="submit" class="btn btn-primary">Submit</button>

</form>