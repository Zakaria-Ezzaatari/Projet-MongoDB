<?php include  __DIR__. "/../core/header.php";?>


<form action="index.php?controller=login&action=login" method="post">
        
    <div class="mb-3">
        <label for="user" class="form-label">Utilisateur</label>
        <input type="text" class="form-control" name="user" id="user" aria-describedby="userHelp" required>
    </div>
    <div class="mb-3">
    <label for="password" class="form-label">Mot de Passe</label>
    <input type="password" name="password" id="password" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</body>
</html>

    

