<?php include  __DIR__. "/../core/header.php";?>

<h1>Ajouter un cours</h1>

<form action="index.php?controller=enseignant&action=add" method="post">
    
    <div class="mb-3">
        <label for="cours" class="form-label">Nom du Cours</label>
        <input type="text" class="form-control form-control-sm" id="cours" name="cours">  
        <label for="description" class="form-label">Descriptif:</label>
        <textarea class="form-control" name="description" id="description" rows="3"></textarea>
    </div>
        <button type="submit" class="btn btn-primary">Submit</button>
</form>

<h1>Modifier mes cours</h1>

<form action="index.php?controller=enseignant&action=update" method="post">
  <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Description</th>
      <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php 
        $count=0;
        foreach($data as $cours)
        {
            echo "<tr>\n";
            echo "<td>\n";
            echo"<input type='text' class='form-control form-control-sm' id='cours[]' name='cours[]' value='" . $cours['nom_cours'] ."'>\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "<textarea class='form-control' id='description[]' name='description[]' rows='1'   >" . $cours['description_cours'] . "</textarea>\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "<div class='form-check'>\n";
            echo "<input class='form-check-input' type='checkbox' value='" . $count . "' name='checkbox[]' id='flexCheckDefault'>\n";
            echo "</div>\n";
            echo "</td>\n";
            echo "</tr>\n";
            $count++;
    }
    ?>
    </tbody>
  </table>
  <button type="submit" class="btn btn-primary">Submit</button>

</form>

<h1>Supprimer mes cours</h1>

<form action="index.php?controller=enseignant&action=remove" method="post">
  <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Nom</th>
      <th scope="col">Description</th>
      <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php 
        $count=0;
        foreach($data as $cours)
        {
            echo "<tr>\n";
            echo "<td>\n";
            echo "" . $cours['nom_cours'] . "\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "" . $cours['description_cours'] . "\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "<div class='form-check'>\n";
            echo "<input class='form-check-input' type='checkbox' value='" . $count . "' name='checkbox[]' id='flexCheckDefault'>\n";
            echo "</div>\n";
            echo "</td>\n";
            echo "</tr>\n";
            $count++;
    }
    ?>
    </tbody>
  </table>
  <button type="submit" class="btn btn-primary">Submit</button>

</form>