<?php
define("CONTROLLER_DEFAULT", "login");
define("DEFAULT_ACTION", "index");
?>