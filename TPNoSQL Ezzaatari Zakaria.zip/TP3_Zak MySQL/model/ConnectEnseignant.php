<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectEnseignant extends Connect
    {
        public function addSubject($cours,$description,$user)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("INSERT INTO cours (nom_cours,description_cours,createur_cours) VALUES (?,?,?) ");
            $stmt->execute(array($cours,$description,$user));
        }

        public function updateSubjects($cours,$description,$check,$user)
        {
            $conn=$this->Connection();
            $table=$this->getSubjects($user);
            foreach($check as $index)
            {
                $element=$table[$index]['nom_cours'];
            
                $stmt = $conn->prepare("UPDATE cours SET nom_cours=?,description_cours=? WHERE nom_cours=?");
                $stmt->execute(array($cours[$index],$description[$index],$element));
            }
            
        }


        public function removeSubjects($subject,$user)
        {
            $conn=$this->Connection();
            $table=$this->getSubjects($user);
            foreach($subject as $index)
            {
            $element=$table[$index]['nom_cours'];
            
            $stmt = $conn->prepare("DELETE FROM cours WHERE nom_cours= ?");
            $stmt->execute(array($element));
            }
        }

        public function getSubjects($user)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM cours WHERE createur_cours=?");
            $stmt->execute(array($user));
            $result=$stmt->fetchAll();
            return $result;
        }
    }