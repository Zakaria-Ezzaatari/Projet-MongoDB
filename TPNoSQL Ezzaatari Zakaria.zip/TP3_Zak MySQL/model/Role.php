<?php
class Role
{
    private $Connection;

    public function __construct($Connection)
    {
        $this->Connection=$Connection;
    }

    public function getRole($user)
    {
        $this->Connection->getRole($user);
    }
}