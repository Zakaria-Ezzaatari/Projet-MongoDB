<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectForm extends Connect
    {        
        function verifyLogin($user,$password)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE login_user = ? AND login_password= ?");
            $stmt->execute(array($user,$password));
            $result=$stmt->fetch();
            if($stmt->rowCount() !== 0) 
            {
               return true;
            }
            return false;
        }

        function getRole($user)
        {
            $conn=$this->Connection();
            $stmt = $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE login_user = ?");
            $stmt->execute(array($user));
            $result=$stmt->fetch();
            return $result;
        }

        function addMessage($message,$user)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("INSERT INTO messages (post_message,user_message) VALUES (?,?) ");
            $stmt->execute(array($message,$user));
        }

        function getMessages()
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM messages");
            $stmt->execute();
            $result=$stmt->fetchAll();
            return $result;
        }

    }


?>