<?php

class Enseignant
{
    private $Connection;

    public function __construct($Connection)
    {
        $this->Connection=$Connection;
    }

    public function addSubject($cours,$description,$user)
    {
        $this->Connection->addSubject($cours,$description,$user);
    }

    public function updateSubjects($cours,$description,$check,$user)
    {
        $this->Connection->updateSubjects($cours,$description,$check,$user);
    }

    public function removeSubjects($subject,$user)
    {
        $this->Connection->removeSubjects($subject,$user);
    }

    public function getSubjects($user)
    {
        return $this->Connection->getSubjects($user);
    }

    
}