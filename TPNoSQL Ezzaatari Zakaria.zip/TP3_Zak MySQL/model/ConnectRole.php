<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectRole extends Connect
    {
        function getRole($user)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("SELECT login_role FROM utilisateurs WHERE login_user= ?");
            $stmt->execute(array($user));
            $result=$stmt->fetch();
            if($stmt->rowCount() !== 0) 
            {
                return $result;
            }
            else
            {
                return false;
            }
        }

    }