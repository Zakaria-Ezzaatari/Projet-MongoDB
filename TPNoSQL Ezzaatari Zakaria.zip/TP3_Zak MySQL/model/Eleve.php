<?php

class Eleve
{
    private $Connection;

    public function __construct($Connection)
    {
        $this->Connection=$Connection;
    }

    public function getSubjects($user)
    {
        return $this->Connection->getSubjects($user);
    }

    public function allSubjects()
    {
        return $this->Connection->allSubjects();
    }

    public function subscribeSubjects($check,$user)
    {
        $this->Connection->subscribeSubjects($check,$user);
    }

}