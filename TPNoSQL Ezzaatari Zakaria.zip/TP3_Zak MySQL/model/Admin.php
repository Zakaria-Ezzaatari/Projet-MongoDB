<?php

class Admin
{
    private $Connection;

    public function __construct($Connection)
    {
        $this->Connection=$Connection;
    }

    public function addUser($login,$password,$role)
    {
        $this->Connection->addUser($login,$password,$role);
    }

    public function removeUser($user)
    {
        $this->Connection->removeUser($user);
    }

    public function getUsers()
    {
        return $this->Connection->getUsers();
    }
}