<?php
    require_once __DIR__. "/../core/Connect.php";
    Class ConnectAdmin extends Connect
    {
        public function addUser($login,$password,$role)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("INSERT INTO utilisateurs (login_user,login_password,login_role) VALUES (?,?,?) ");
            $stmt->execute(array($login,$password,$role));
        }

        function removeUser($user)
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("DELETE FROM utilisateurs WHERE login_user= ?");
            $stmt->execute(array($user));
        }

        function getUsers()
        {
            $conn=$this->Connection();
            $stmt = $conn->prepare("SELECT * FROM utilisateurs");
            $stmt->execute();
            $result=$stmt->fetchAll();
            return $result;
        }
    }