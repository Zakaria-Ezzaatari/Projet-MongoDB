<?php
class Login
{
    private $Connection;

    private $user;
    private $password;

    public function __construct($Connection)
    {
        $this->Connection=$Connection;
    }

    public function getUser() {
        return $this->user;
    }

    public function setUser($user) {
        $this->user = $user;
    } 

    public function getPassword() {
        return $this->password;
    }

    public function setPassword($password) {
        $this->password = $password;
    } 

    public function getRole($user)
    {
        $result=$this->Connection->getRole($user);
        return $result;
    }
    
    public function verify($user,$password)
    {
        $verify=$this->Connection->verifyLogin($user,$password);
        if ($verify==true)
        {
            $this->setUser($user);
            $this->setPassword($password);
            return true;
        }
        return false;
    }

    public function message($message,$user)
    {
        $this->Connection->addMessage($message,$user);
    }

    public function getMessages()
    {
        return $this->Connection->getMessages();
    }
}