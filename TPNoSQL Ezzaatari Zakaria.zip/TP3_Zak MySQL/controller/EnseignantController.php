<?php

class EnseignantController
{
    private $connect;
    private $Connection;

    public function __construct()
    {
        require_once __DIR__. "/../model/ConnectEnseignant.php";
        require_once __DIR__ . "/../model/Enseignant.php";

        $this->connect=new ConnectEnseignant();
        $this->Connection=$this->connect->Connection();

    }

    public function run($action)
    {
        switch($action)
        {
            case "enseignant" :
                $this->enseignant();
                break;
            case "add" :
                $this->add();
                break;
            case "update" :
                $this->update();
                break;
            case "remove" :
                $this->remove();
                break;
            default:
                $this->enseignant();
                break;
        }
    }

    public function enseignant()
    {
        $enseignant=new Enseignant($this->connect);
        $cours=$enseignant->getSubjects($_SESSION['user']);
        

        $this->view("enseignant",$cours);
    }

    public function add()
    {
        if((isset($_POST['cours'])&&isset($_POST['description'])))
        {
            $enseignant=new Enseignant($this->connect);
            $enseignant->addSubject($_POST['cours'],$_POST['description'],$_SESSION['user']);
        }
            $this->run("enseignant");
        
    }

    public function update()
    {
        //echo $_POST['cours'][$_POST['checkbox'][1]];

        if((isset($_POST['cours']))&&(isset($_POST['description']))&&(isset($_POST['checkbox'])))
        {
            $enseignant=new Enseignant($this->connect);
            $enseignant->updateSubjects($_POST['cours'],$_POST['description'],$_POST['checkbox'],$_SESSION['user']);
        }
        $this->run("enseignant");
    }

    public function remove()
    {
        if((isset($_POST['checkbox'])))
        {
            $enseignant=new Enseignant($this->connect);
            $enseignant->removeSubjects($_POST['checkbox'],$_SESSION['user']);
        }
        $this->run("enseignant");
    }

    public function view($view,$array)
    {
        $data=$array;
        require_once __DIR__ . "/../view/" . $view . "View.php";
        
    }

}