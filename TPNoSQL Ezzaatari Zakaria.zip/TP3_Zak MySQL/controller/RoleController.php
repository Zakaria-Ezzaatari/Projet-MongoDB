<?php
class RoleController
{
    private $connect;
    private $Connection;

    public function __construct()
    {
        require_once __DIR__. "/../model/ConnectRole.php";
        require_once __DIR__ . "/../model/Role.php";

        $this->connect=new ConnectRole();
        $this->Connection=$this->connect->Connection();

    }

    public function run($action)
    {
        switch($action)
        {
            case "role" :
                $this->role();
                break;
            case "admin" :
                $this->admin();
                break;
            case "enseignant" :
                $this->enseignant();
                break;
            case "eleve" :
                $this->eleve();
                break;
            default:
                $this->role();
                break;
        }
    }

    public function role()
    {
        if (isset($_SESSION['user']))
        {
            $role=new Role($this->connect);
            $action=$role->getRole($_SESSION["user"]);
            switch($action)
            {
                case false :
                    loadController("login");
                case "admin" :
                    loadController("admin");
                    
                case "enseignant" :
                    loadController("enseignant");
                case "eleve" :
                    loadController("eleve");
                default :
                    loadController("login");
            }
        }
    }
}