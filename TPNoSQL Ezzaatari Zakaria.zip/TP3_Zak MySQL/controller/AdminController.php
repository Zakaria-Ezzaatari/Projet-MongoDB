<?php

class AdminController
{
    private $connect;
    private $Connection;

    public function __construct()
    {
        require_once __DIR__. "/../model/ConnectAdmin.php";
        require_once __DIR__ . "/../model/Admin.php";

        $this->connect=new ConnectAdmin();
        $this->Connection=$this->connect->Connection();

    }

    public function run($action)
    {
        switch($action)
        {
            case "admin" :
                $this->admin();
                break;
            case "add" :
                $this->add();
                break;
            case "remove" :
                $this->remove();
                break;
            default:
                $this->admin();
                break;
        }
    }
    public function admin()
    {
        $admin=new Admin($this->connect);
        $users=$admin->getUsers();
        $this->view("admin",$users);
    }
    
    public function add()
    {
        if((isset($_POST['login']))&&(isset($_POST['pass']))&&(isset($_POST['role'])))
        {
            $admin=new Admin($this->connect);
            $admin->addUser($_POST['login'],$_POST['pass'],$_POST['role']);
        }
        $this->run("admin");
        
    }

    public function remove()
    {
        if(isset($_POST['remove']))
        {
            $admin=new Admin($this->connect);
            $admin->removeUser($_POST['remove']);
        }
        $this->run("admin");
    }
        
    public function view($view,$array)
    {
        $data=$array;
        require_once __DIR__ . "/../view/" . $view . "View.php";
    }
    
    }