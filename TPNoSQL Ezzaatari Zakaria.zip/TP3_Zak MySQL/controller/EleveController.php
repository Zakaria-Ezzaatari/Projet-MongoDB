<?php

class EleveController
{
    private $connect;
    private $Connection;

    public function __construct()
    {
        require_once __DIR__. "/../model/ConnectEleve.php";
        require_once __DIR__ . "/../model/Eleve.php";

        $this->connect=new ConnectEleve();
        $this->Connection=$this->connect->Connection();

    }

    public function run($action)
    {
        switch($action)
        {
            case "eleve" :
                $this->eleve();
                break;
            case "subscribe" :
                $this->subscribe();
                break;
            default:
                $this->eleve();
                break;
        }
    }

    public function eleve()
    {
        $eleve=new Eleve($this->connect);
        $subs=$eleve->getSubjects($_SESSION['user']);
        $cours=$eleve->allSubjects();
        $this->view("eleve",array(
            "subs"=>$subs,
            "cours"=>$cours
            ));
    }

    public function subscribe()
    {
        if(isset($_POST['checkbox']))
        {
            $eleve=new Eleve($this->connect);
            $eleve->subscribeSubjects($_POST['checkbox'],$_SESSION['user']);
        }
        $this->run("eleve");
    }

    public function view($view,$array)
    {
        $data=$array;
        require_once __DIR__ . "/../view/" . $view . "View.php";
        
    }
}