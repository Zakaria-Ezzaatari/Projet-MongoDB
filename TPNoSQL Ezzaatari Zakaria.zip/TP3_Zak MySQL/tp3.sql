-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 21, 2022 alle 20:44
-- Versione del server: 10.4.21-MariaDB
-- Versione PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tp3`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `cours`
--

CREATE TABLE `cours` (
  `id_cours` int(11) NOT NULL,
  `nom_cours` varchar(60) NOT NULL,
  `description_cours` varchar(250) NOT NULL,
  `createur_cours` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `cours`
--

INSERT INTO `cours` (`id_cours`, `nom_cours`, `description_cours`, `createur_cours`) VALUES
(1, 'Lecture 2', 'Il faut beaucoup lire pour etre bon', 'Paul Dupont'),
(6, 'Base de Donnes', 'SQL et noSQL', 'Paul Dupont'),
(7, 'RPG en PHP', 'Pretty good, huh?', 'Stephanie Lefrancois');

-- --------------------------------------------------------

--
-- Struttura della tabella `messages`
--

CREATE TABLE `messages` (
  `id_message` int(11) NOT NULL,
  `post_message` varchar(255) NOT NULL,
  `user_message` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `messages`
--

INSERT INTO `messages` (`id_message`, `post_message`, `user_message`) VALUES
(7, 'PLEASE', 'admin'),
(8, 'TEST1', 'admin'),
(12, 'Banana', 'admin'),
(14, 'POWER', 'admin'),
(15, 'TEST BEFORE DEMO', 'admin'),
(16, 'LUCAS IS HERE', 'Lucas'),
(17, 'test presentation', 'admin');

-- --------------------------------------------------------

--
-- Struttura della tabella `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id_sub` int(11) NOT NULL,
  `nom_sub` varchar(50) NOT NULL,
  `description_sub` varchar(250) NOT NULL,
  `enseignant_sub` varchar(50) NOT NULL,
  `eleve_sub` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `subscriptions`
--

INSERT INTO `subscriptions` (`id_sub`, `nom_sub`, `description_sub`, `enseignant_sub`, `eleve_sub`) VALUES
(1, 'RPG en PHP', 'Pretty good, huh?', 'Stephanie Lefrancois', 0),
(3, 'Base de Donnes', 'SQL et noSQL', 'Paul Dupont', 0),
(4, 'Lecture 2', 'Il faut beaucoup lire pour etre bon', 'Paul Dupont', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id_user` int(11) NOT NULL,
  `login_user` varchar(30) NOT NULL,
  `login_password` varchar(30) NOT NULL,
  `login_role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utilisateurs`
--

INSERT INTO `utilisateurs` (`id_user`, `login_user`, `login_password`, `login_role`) VALUES
(1, 'admin', 'admin', 'admin'),
(2, 'Paul Dupont', 'Paul', 'enseignant'),
(3, 'Eric Dupont', 'Eric', 'enseignant'),
(13, 'Stephanie Lefrancois', 'Steph', 'enseignant'),
(14, 'Lucas', 'Lucas', 'eleve'),
(15, 'Agent 47', 'hm', 'eleve'),
(17, 'Carl', 'A', 'enseignant');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`id_cours`);

--
-- Indici per le tabelle `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indici per le tabelle `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id_sub`);

--
-- Indici per le tabelle `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `cours`
--
ALTER TABLE `cours`
  MODIFY `id_cours` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT per la tabella `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id_sub` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
